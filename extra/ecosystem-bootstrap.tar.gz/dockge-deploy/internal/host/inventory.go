package host

import (
	"fmt"
	"strconv"
	"strings"

	"github.com/wkarts/dockge/dockge-deploy/internal/sshx"
)

type Inventory struct {
	Hostname         string `json:"hostname"`
	Kernel           string `json:"kernel"`
	Arch             string `json:"arch"`
	Distro           string `json:"distro"`
	DistroVersion    string `json:"distro_version"`
	UID              int    `json:"uid"`
	DockerInstalled  bool   `json:"docker_installed"`
	DockerVersion    string `json:"docker_version"`
	ComposeInstalled bool   `json:"compose_installed"`
	ComposeVersion   string `json:"compose_version"`
}

func Inspect(c *sshx.Client) (*Inventory, error) {
	run := func(cmd string) string {
		o, _, _ := c.Run(cmd)
		return strings.TrimSpace(o)
	}
	uid, _ := strconv.Atoi(run("id -u"))
	inv := &Inventory{
		Hostname: run("hostname"),
		Kernel:   run("uname -sr"),
		Arch:     run("uname -m"),
		UID:      uid,
	}
	osrel := run(`. /etc/os-release 2>/dev/null || true; printf '%s|%s' "${ID:-unknown}" "${VERSION_ID:-unknown}"`)
	parts := strings.SplitN(osrel, "|", 2)
	if len(parts) > 0 {
		inv.Distro = parts[0]
	}
	if len(parts) > 1 {
		inv.DistroVersion = parts[1]
	}
	if v := run("docker version --format '{{.Server.Version}}' 2>/dev/null"); v != "" {
		inv.DockerInstalled = true
		inv.DockerVersion = v
	}
	if v := run("docker compose version --short 2>/dev/null"); v != "" {
		inv.ComposeInstalled = true
		inv.ComposeVersion = v
	}
	return inv, nil
}

func RequireRoot(c *sshx.Client, operation string) error {
	out, _, err := c.Run("id -u")
	if err != nil {
		return fmt.Errorf("cannot determine remote uid: %w", err)
	}
	if strings.TrimSpace(out) != "0" {
		return fmt.Errorf("%s requires an SSH session as root in Dockge Deploy 1.0; read-only/API operations may use an unprivileged account", operation)
	}
	return nil
}

// InstallDocker supports the major Linux package families while keeping a
// conservative rule: an existing Docker Engine + Compose v2 is never replaced.
// Debian/RPM families use Docker's official convenience bootstrap; Alpine and
// Arch use their native repositories because get.docker.com does not cover them.
func InstallDocker(c *sshx.Client) error {
	if err := RequireRoot(c, "Docker installation"); err != nil {
		return err
	}
	cmd := `set -eu
if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
  docker version
  docker compose version
  exit 0
fi
. /etc/os-release 2>/dev/null || true
id="${ID:-unknown}"
like="${ID_LIKE:-}"
case "$id:$like" in
  alpine:*)
    apk add --no-cache docker docker-cli-compose
    rc-update add docker default >/dev/null 2>&1 || true
    rc-service docker start >/dev/null 2>&1 || true
    ;;
  arch:*|manjaro:*)
    pacman -Sy --noconfirm docker docker-compose
    systemctl enable --now docker
    ;;
  debian:*|ubuntu:*|raspbian:*|*:debian*|*:ubuntu*|fedora:*|centos:*|rhel:*|rocky:*|almalinux:*|ol:*|*:rhel*|*:fedora*)
    if command -v curl >/dev/null 2>&1; then
      tmp=$(mktemp); trap 'rm -f "$tmp"' EXIT
      curl -fsSL https://get.docker.com -o "$tmp"
      sh "$tmp"
    elif command -v wget >/dev/null 2>&1; then
      tmp=$(mktemp); trap 'rm -f "$tmp"' EXIT
      wget -qO "$tmp" https://get.docker.com
      sh "$tmp"
    else
      echo 'curl or wget is required to bootstrap the official Docker repository' >&2
      exit 41
    fi
    systemctl enable --now docker 2>/dev/null || service docker start 2>/dev/null || true
    ;;
  *)
    echo "Unsupported automatic Docker installation for distro ID=$id ID_LIKE=$like" >&2
    echo 'Install Docker Engine + Compose v2 using the distribution vendor, then rerun dockge-deploy.' >&2
    exit 42
    ;;
esac
docker version
docker compose version`
	o, e, err := c.Run(cmd)
	if err != nil {
		return fmt.Errorf("install docker failed: %w\n%s\n%s", err, o, e)
	}
	return nil
}
