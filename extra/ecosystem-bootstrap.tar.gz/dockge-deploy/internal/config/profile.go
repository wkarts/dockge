package config

import (
	"encoding/json"
	"fmt"
	"net/url"
	"os"
	"path/filepath"
	"strings"
)

type Profile struct {
	Name   string       `json:"name"`
	SSH    SSHConfig    `json:"ssh"`
	Dockge DockgeConfig `json:"dockge"`
}

type SSHConfig struct {
	Host           string `json:"host"`
	Port           int    `json:"port"`
	User           string `json:"user"`
	PrivateKeyPath string `json:"private_key_path,omitempty"`
	PasswordEnv    string `json:"password_env,omitempty"`
	UseSSHAgent    bool   `json:"use_ssh_agent,omitempty"`
	HostKeySHA256  string `json:"host_key_sha256,omitempty"`
	KnownHostsPath string `json:"known_hosts_path,omitempty"`
}

type DockgeConfig struct {
	URL       string `json:"url,omitempty"`
	TokenEnv  string `json:"token_env,omitempty"`
	VerifyTLS *bool  `json:"verify_tls,omitempty"`
}

func (c DockgeConfig) TLSVerificationEnabled() bool {
	return c.VerifyTLS == nil || *c.VerifyTLS
}

func expand(path string) string {
	if strings.HasPrefix(path, "~/") {
		if h, err := os.UserHomeDir(); err == nil {
			return filepath.Join(h, path[2:])
		}
	}
	return path
}

func Load(path string) (*Profile, error) {
	b, err := os.ReadFile(expand(path))
	if err != nil {
		return nil, err
	}
	var p Profile
	if err := json.Unmarshal(b, &p); err != nil {
		return nil, err
	}
	if p.SSH.Port == 0 {
		p.SSH.Port = 22
	}
	p.SSH.Host = strings.TrimSpace(p.SSH.Host)
	p.SSH.User = strings.TrimSpace(p.SSH.User)
	if p.SSH.Host == "" || p.SSH.User == "" {
		return nil, fmt.Errorf("profile requires ssh.host and ssh.user")
	}
	p.SSH.PrivateKeyPath = expand(p.SSH.PrivateKeyPath)
	p.SSH.KnownHostsPath = expand(p.SSH.KnownHostsPath)
	p.SSH.HostKeySHA256 = strings.TrimSpace(p.SSH.HostKeySHA256)

	if p.Dockge.URL != "" {
		parsed, err := url.Parse(strings.TrimSpace(p.Dockge.URL))
		if err != nil || parsed.Host == "" || (parsed.Scheme != "https" && parsed.Scheme != "http") {
			return nil, fmt.Errorf("dockge.url must be an absolute http/https URL")
		}
		if parsed.Scheme == "http" && p.Dockge.TLSVerificationEnabled() {
			// HTTP has no TLS to verify, but requiring an explicit false keeps
			// cleartext transport deliberate rather than accidental.
			return nil, fmt.Errorf("dockge.url uses cleartext HTTP; set verify_tls=false explicitly only for a trusted private/loopback path")
		}
		p.Dockge.URL = strings.TrimRight(parsed.String(), "/")
	}
	return &p, nil
}
