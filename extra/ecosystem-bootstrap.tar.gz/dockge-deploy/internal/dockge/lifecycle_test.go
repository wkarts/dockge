package dockge

import (
	"strings"
	"testing"
)

func TestCanonicalComposeKeepsDockgeRuntimeContract(t *testing.T) {
	s := canonicalCompose()
	for _, want := range []string{
		"${DOCKGE_IMAGE:-ghcr.io/wkarts/dockge}:${DOCKGE_IMAGE_TAG:-latest}",
		"${DOCKGE_DATA_PATH:-./data}:/app/data",
		"${DOCKGE_STACKS_PATH:-/opt/stacks}:${DOCKGE_STACKS_PATH:-/opt/stacks}",
		"DOCKGE_API_IDEMPOTENCY_FILE",
		"no-new-privileges:true",
	} {
		if !strings.Contains(s, want) {
			t.Fatalf("missing %q", want)
		}
	}
}

func TestCanonicalEnvPinsRuntime(t *testing.T) {
	s := canonicalEnv("1.6.1", "/data", "/srv/stacks", "127.0.0.1", 5001)
	for _, want := range []string{
		"DOCKGE_IMAGE_TAG=1.6.1",
		"DOCKGE_DATA_PATH=/data",
		"DOCKGE_STACKS_PATH=/srv/stacks",
		"DOCKGE_BIND_HOST=127.0.0.1",
		"DOCKGE_PORT=5001",
	} {
		if !strings.Contains(s, want) {
			t.Fatalf("missing %q", want)
		}
	}
}

func TestValidateTag(t *testing.T) {
	for _, valid := range []string{"1.6.1", "latest", "develop-abc123"} {
		if err := ValidateTag(valid); err != nil {
			t.Fatalf("expected valid tag %q: %v", valid, err)
		}
	}
	for _, invalid := range []string{"bad tag", "../oops", "tag;rm"} {
		if err := ValidateTag(invalid); err == nil {
			t.Fatalf("expected invalid tag %q", invalid)
		}
	}
}
