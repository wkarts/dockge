package api

import (
	"bytes"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"strings"
	"time"

	"github.com/wkarts/dockge/dockge-deploy/internal/config"
)

type Client struct {
	Base  string
	Token string
	HTTP  *http.Client
}

func New(p *config.Profile) (*Client, error) {
	if p.Dockge.URL == "" {
		return nil, fmt.Errorf("profile dockge.url is required")
	}
	if p.Dockge.TokenEnv == "" {
		return nil, fmt.Errorf("profile dockge.token_env is required")
	}
	tok := os.Getenv(p.Dockge.TokenEnv)
	if tok == "" {
		return nil, fmt.Errorf("environment variable %s is empty", p.Dockge.TokenEnv)
	}
	tr := &http.Transport{}
	if !p.Dockge.TLSVerificationEnabled() {
		// Explicitly requested by profile. This is only intended for a trusted
		// private/loopback path; HTTPS verification is the default.
		tr.TLSClientConfig = &tls.Config{InsecureSkipVerify: true} // #nosec G402
	}
	return &Client{
		Base:  strings.TrimRight(p.Dockge.URL, "/") + "/api/v1/automation",
		Token: tok,
		HTTP:  &http.Client{Transport: tr, Timeout: 10 * time.Minute},
	}, nil
}

func EscapePath(value string) string { return url.PathEscape(value) }

func (c *Client) Do(method, path string, body any, idem string) (map[string]any, error) {
	var r io.Reader
	if body != nil {
		b, err := json.Marshal(body)
		if err != nil {
			return nil, err
		}
		r = bytes.NewReader(b)
	}
	req, err := http.NewRequest(method, c.Base+path, r)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Authorization", "Bearer "+c.Token)
	req.Header.Set("Accept", "application/json")
	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	if idem != "" {
		req.Header.Set("Idempotency-Key", idem)
	}
	resp, err := c.HTTP.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	b, err := io.ReadAll(io.LimitReader(resp.Body, 4<<20))
	if err != nil {
		return nil, err
	}
	var out map[string]any
	if len(b) == 0 {
		out = map[string]any{}
	} else if err := json.Unmarshal(b, &out); err != nil {
		out = map[string]any{"raw": string(b)}
	}
	if resp.StatusCode >= 400 {
		return nil, fmt.Errorf("Dockge API HTTP %d: %v", resp.StatusCode, out)
	}
	return out, nil
}
