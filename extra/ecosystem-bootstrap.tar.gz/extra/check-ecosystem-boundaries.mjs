import fs from "node:fs";
import path from "node:path";

const root = process.cwd();

function walk(dir) {
    if (!fs.existsSync(dir)) return [];
    return fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) return walk(full);
        return [full];
    });
}

function assertNoMatch(files, patterns, label) {
    for (const file of files) {
        const text = fs.readFileSync(file, "utf8");
        for (const pattern of patterns) {
            if (pattern.test(text)) {
                throw new Error(`${label}: forbidden dependency ${pattern} found in ${path.relative(root, file)}`);
            }
        }
    }
}

const managerFiles = [
    ...walk(path.join(root, "dockge-manager", "backend", "app")),
    ...walk(path.join(root, "dockge-manager", "frontend", "src")),
    path.join(root, "dockge-manager", "compose.yaml"),
    path.join(root, "dockge-manager", "Dockerfile"),
].filter(fs.existsSync);

assertNoMatch(managerFiles, [
    /\/var\/run\/docker\.sock/,
    /redbean-node/,
    /backend\/agent-manager/,
    /common\/agent-socket/,
], "Dockge Manager boundary");

const clientFile = path.join(root, "dockge-manager", "backend", "app", "dockge_client.py");
if (fs.existsSync(clientFile) && !fs.readFileSync(clientFile, "utf8").includes("/api/v1/automation")) {
    throw new Error("Dockge Manager must use the public Automation API contract");
}

const deployRuntime = [
    ...walk(path.join(root, "dockge-deploy", "cmd")),
    ...walk(path.join(root, "dockge-deploy", "internal")),
];
assertNoMatch(deployRuntime, [
    /backend\/agent-manager/,
    /common\/agent-socket/,
    /redbean-node/,
], "Dockge Deploy boundary");

console.log("Ecosystem boundaries OK: Core, Manager, Deploy and Native Agents remain separated.");
