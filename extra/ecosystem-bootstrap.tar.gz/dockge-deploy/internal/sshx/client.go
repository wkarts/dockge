package sshx

import (
	"bytes"
	"crypto/sha256"
	"encoding/base64"
	"fmt"
	"net"
	"os"
	"strings"
	"time"

	"github.com/wkarts/dockge/dockge-deploy/internal/config"
	"golang.org/x/crypto/ssh"
	"golang.org/x/crypto/ssh/agent"
	"golang.org/x/crypto/ssh/knownhosts"
)

type Client struct {
	Conn *ssh.Client
}

func Fingerprint(pub ssh.PublicKey) string {
	sum := sha256.Sum256(pub.Marshal())
	return "SHA256:" + base64.RawStdEncoding.EncodeToString(sum[:])
}

// HostFingerprint obtains the server key fingerprint for first-time inspection.
// It intentionally does not establish trust; the fingerprint must then be
// written to host_key_sha256 (or a known_hosts file must be configured).
func HostFingerprint(profile *config.Profile) (string, error) {
	addr := fmt.Sprintf("%s:%d", profile.SSH.Host, profile.SSH.Port)
	var got string
	cfg := &ssh.ClientConfig{
		User: profile.SSH.User,
		HostKeyCallback: func(_ string, _ net.Addr, key ssh.PublicKey) error {
			got = Fingerprint(key)
			return fmt.Errorf("fingerprint-only")
		},
		Timeout: 8 * time.Second,
	}
	conn, err := net.DialTimeout("tcp", addr, 8*time.Second)
	if err != nil {
		return "", err
	}
	defer conn.Close()
	_, _, _, err = ssh.NewClientConn(conn, addr, cfg)
	if got != "" {
		return got, nil
	}
	return "", err
}

func hostKeyCallback(c config.SSHConfig) (ssh.HostKeyCallback, error) {
	if c.HostKeySHA256 != "" {
		expected := strings.TrimSpace(c.HostKeySHA256)
		return func(_ string, _ net.Addr, key ssh.PublicKey) error {
			got := Fingerprint(key)
			if got != expected {
				return fmt.Errorf("SSH host key mismatch: expected %s got %s", expected, got)
			}
			return nil
		}, nil
	}
	if c.KnownHostsPath != "" {
		return knownhosts.New(c.KnownHostsPath)
	}
	return nil, fmt.Errorf("host verification required: configure host_key_sha256 or known_hosts_path")
}

func authMethods(c config.SSHConfig) ([]ssh.AuthMethod, func(), error) {
	var methods []ssh.AuthMethod
	cleanup := func() {}

	if c.PrivateKeyPath != "" {
		key, err := os.ReadFile(c.PrivateKeyPath)
		if err != nil {
			return nil, cleanup, fmt.Errorf("read private key: %w", err)
		}
		signer, err := ssh.ParsePrivateKey(key)
		if err != nil {
			return nil, cleanup, fmt.Errorf("parse private key (encrypted keys should use ssh-agent): %w", err)
		}
		methods = append(methods, ssh.PublicKeys(signer))
	}

	if c.PasswordEnv != "" {
		if v := os.Getenv(c.PasswordEnv); v != "" {
			methods = append(methods, ssh.Password(v))
		}
	}

	if c.UseSSHAgent {
		// Unix/macOS and environments that expose a Unix-compatible agent
		// socket are supported directly. On Windows, private key/password
		// authentication remains available when SSH_AUTH_SOCK is not a Unix socket.
		sock := os.Getenv("SSH_AUTH_SOCK")
		if sock != "" {
			conn, err := net.Dial("unix", sock)
			if err == nil {
				ag := agent.NewClient(conn)
				methods = append(methods, ssh.PublicKeysCallback(ag.Signers))
				cleanup = func() { _ = conn.Close() }
			}
		}
	}

	if len(methods) == 0 {
		return nil, cleanup, fmt.Errorf("no SSH authentication method available")
	}
	return methods, cleanup, nil
}

func Dial(profile *config.Profile) (*Client, error) {
	cb, err := hostKeyCallback(profile.SSH)
	if err != nil {
		return nil, err
	}
	methods, cleanup, err := authMethods(profile.SSH)
	if err != nil {
		return nil, err
	}
	defer cleanup()

	cfg := &ssh.ClientConfig{
		User:            profile.SSH.User,
		Auth:            methods,
		HostKeyCallback: cb,
		Timeout:         12 * time.Second,
	}
	conn, err := ssh.Dial("tcp", fmt.Sprintf("%s:%d", profile.SSH.Host, profile.SSH.Port), cfg)
	if err != nil {
		return nil, err
	}
	return &Client{Conn: conn}, nil
}

func (c *Client) Close() error { return c.Conn.Close() }

func (c *Client) Run(command string) (string, string, error) {
	s, err := c.Conn.NewSession()
	if err != nil {
		return "", "", err
	}
	defer s.Close()
	var out, er bytes.Buffer
	s.Stdout = &out
	s.Stderr = &er
	err = s.Run(command)
	return out.String(), er.String(), err
}

func (c *Client) WriteFile(path string, content []byte, mode string) error {
	s, err := c.Conn.NewSession()
	if err != nil {
		return err
	}
	defer s.Close()
	s.Stdin = bytes.NewReader(content)
	cmd := fmt.Sprintf(
		"umask 077; mkdir -p \"$(dirname %s)\"; cat > %s; chmod %s %s",
		shellQuote(path), shellQuote(path), shellQuote(mode), shellQuote(path),
	)
	if out, err := s.CombinedOutput(cmd); err != nil {
		return fmt.Errorf("write remote file: %w: %s", err, out)
	}
	return nil
}

func ShellQuote(v string) string {
	return "'" + strings.ReplaceAll(v, "'", "'\"'\"'") + "'"
}

func shellQuote(v string) string { return ShellQuote(v) }
